const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_odia_123";
const BOB_UID = "bob_odia_456";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

function buildValidAttemptPayload(uid, overrides = {}) {
  const now = new Date(Date.now() - 1000);
  return {
    userId: uid,
    topicKey: "ANCIENT_MEDIEVAL",
    topicTitleOr: "ପ୍ରାଚୀନ ଓ ମଧ୍ୟଯୁଗୀୟ ସାହିତ୍ୟ",
    difficulty: "MODERATE",
    totalQuestions: 10,
    correctCount: 7,
    wrongCount: 2,
    skippedCount: 1,
    negativeMarkingEnabled: true,
    score: 6.5,
    maxScore: 10.0,
    timeSpentSeconds: 320,
    sourceMode: "GEMINI_AI",
    createdAt: now,
    updatedAt: now,
    ...overrides,
  };
}

function buildValidBookmarkPayload(uid, overrides = {}) {
  const now = new Date(Date.now() - 1000);
  return {
    userId: uid,
    topicKey: "MODERN_POETRY",
    topicTag: "ଗଙ୍ଗାଧର ମେହେର",
    stem: "‘ତପସ୍ୱିନୀ’ କାବ୍ୟର ରଚୟିତା କିଏ?",
    options: ["ରାଧାନାଥ ରାୟ", "ଗଙ୍ଗାଧର ମେହେର", "ମଧୁସୂଦନ ରାଓ", "ଫକୀର ମୋହନ ସେନାପତି"],
    correctIndex: 1,
    explanation: "ସ୍ୱଭାବ କବି ଗଙ୍ଗାଧର ମେହେର ‘ତପସ୍ୱିନୀ’ କାବ୍ୟ ରଚନା କରିଥିଲେ।",
    personalNote: "Important CPET poem",
    createdAt: now,
    updatedAt: now,
    ...overrides,
  };
}

test("Unauthenticated user cannot read or write testAttempts or bookmarks", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthDb.collection("users").doc(ALICE_UID).collection("testAttempts").get());
  await assertFails(
    unauthDb.collection("users").doc(ALICE_UID).collection("testAttempts").doc("att_1").set(
      buildValidAttemptPayload(ALICE_UID)
    )
  );
  await assertFails(unauthDb.collection("users").doc(ALICE_UID).collection("bookmarks").get());
  await assertFails(
    unauthDb.collection("users").doc(ALICE_UID).collection("bookmarks").doc("bm_1").set(
      buildValidBookmarkPayload(ALICE_UID)
    )
  );
});

test("Owner can create, list, get, and delete valid TestAttempt; shadow fields and @DocumentId id fail", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const attemptsCol = aliceDb.collection("users").doc(ALICE_UID).collection("testAttempts");

  await assertSucceeds(attemptsCol.doc("att_1").set(buildValidAttemptPayload(ALICE_UID)));
  await assertSucceeds(attemptsCol.get());
  await assertSucceeds(attemptsCol.doc("att_1").get());

  // Reject immutable update on TestAttempt
  await assertFails(attemptsCol.doc("att_1").update({ score: 10.0 }));

  // Reject @DocumentId "id" stored inside document body
  await assertFails(
    attemptsCol.doc("att_2").set(buildValidAttemptPayload(ALICE_UID, { id: "att_2" }))
  );

  // Reject ghost field
  await assertFails(
    attemptsCol.doc("att_3").set(buildValidAttemptPayload(ALICE_UID, { isVerified: true }))
  );

  // Reject future timestamp
  await assertFails(
    attemptsCol.doc("att_4").set(
      buildValidAttemptPayload(ALICE_UID, { createdAt: new Date(Date.now() + 60000) })
    )
  );

  // Reject invalid total count math
  await assertFails(
    attemptsCol.doc("att_5").set(buildValidAttemptPayload(ALICE_UID, { correctCount: 9 }))
  );

  // Owner can delete
  await assertSucceeds(attemptsCol.doc("att_1").delete());
});

test("Owner can create, list, update personalNote, and delete BookmarkedQuestion", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bookmarksCol = aliceDb.collection("users").doc(ALICE_UID).collection("bookmarks");

  await assertSucceeds(bookmarksCol.doc("bm_1").set(buildValidBookmarkPayload(ALICE_UID)));
  await assertSucceeds(bookmarksCol.get());

  // Valid partial update of personalNote + updatedAt
  await assertSucceeds(
    bookmarksCol.doc("bm_1").update({
      personalNote: "Revise Chhanda and Alankara",
      updatedAt: new Date(Date.now() - 500),
    })
  );

  // Reject modifying immutable stem or createdAt
  await assertFails(
    bookmarksCol.doc("bm_1").update({
      stem: "Tampered stem",
      updatedAt: new Date(Date.now() - 500),
    })
  );
  await assertFails(
    bookmarksCol.doc("bm_1").update({
      createdAt: new Date(Date.now() - 500),
      updatedAt: new Date(Date.now() - 500),
    })
  );

  // Reject invalid options array size
  await assertFails(
    bookmarksCol.doc("bm_2").set(
      buildValidBookmarkPayload(ALICE_UID, { options: ["Only one"] })
    )
  );

  await assertSucceeds(bookmarksCol.doc("bm_1").delete());
});

test("Cross-user access is strictly denied", async () => {
  await testEnv.withSecurityRulesDisabled(async (ctx) => {
    const db = ctx.firestore();
    await db.collection("users").doc(BOB_UID).collection("testAttempts").doc("bob_att").set(
      buildValidAttemptPayload(BOB_UID)
    );
    await db.collection("users").doc(BOB_UID).collection("bookmarks").doc("bob_bm").set(
      buildValidBookmarkPayload(BOB_UID)
    );
  });

  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertFails(aliceDb.collection("users").doc(BOB_UID).collection("testAttempts").get());
  await assertFails(aliceDb.collection("users").doc(BOB_UID).collection("testAttempts").doc("bob_att").get());
  await assertFails(aliceDb.collection("users").doc(BOB_UID).collection("testAttempts").doc("bob_att").delete());
  await assertFails(aliceDb.collection("users").doc(BOB_UID).collection("bookmarks").get());
  await assertFails(
    aliceDb.collection("users").doc(BOB_UID).collection("bookmarks").doc("bob_bm").update({
      personalNote: "Hijack",
      updatedAt: new Date(Date.now() - 500),
    })
  );
});
