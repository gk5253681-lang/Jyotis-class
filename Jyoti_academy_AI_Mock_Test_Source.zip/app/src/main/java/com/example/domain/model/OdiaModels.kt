package com.example.domain.model

import androidx.annotation.Keep
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

enum class OdiaTopic(
    val titleEn: String,
    val titleOr: String,
    val syllabusFocus: String
) {
    FULL_SYLLABUS(
        titleEn = "Full CPET Mock",
        titleOr = "ସମ୍ପୂର୍ଣ୍ଣ ପାଠ୍ୟକ୍ରମ (Full Mock)",
        syllabusFocus = "ପ୍ରାଚୀନ ଓ ମଧ୍ୟଯୁଗୀୟ ସାହିତ୍ୟ, ଆଧୁନିକ ଓଡ଼ିଆ କବିତା, ଗଦ୍ୟ-ଉପନ୍ୟାସ-ନାଟକ, ଓଡ଼ିଆ ବ୍ୟାକରଣ ଓ ଭାଷାତତ୍ତ୍ୱ, ଏବଂ ସାହିତ୍ୟ ତତ୍ତ୍ୱ ଓ ସମାଲୋଚନା"
    ),
    ANCIENT_MEDIEVAL(
        titleEn = "Ancient & Medieval Lit",
        titleOr = "ପ୍ରାଚୀନ ଓ ମଧ୍ୟଯୁଗୀୟ ସାହିତ୍ୟ",
        syllabusFocus = "ଚର୍ଯ୍ୟାଗୀତି, ସାରଳା ଦାସ (ମହାଭାରତ, ବିଲଙ୍କା ରାମାୟଣ), ପଞ୍ଚସଖା (ଜଗନ୍ନାଥ, ବଳରାମ, ଅଚ୍ୟୁତାନନ୍ଦ, ଯଶୋବନ୍ତ, ଅନନ୍ତ), ରୀତି ଯୁଗ (ଉପେନ୍ଦ୍ର ଭଞ୍ଜ, ଦୀନକୃଷ୍ଣ, ଅଭିମନ୍ୟୁ ସାମନ୍ତସିଂହାର, କବିସୂର୍ଯ୍ୟ ବଳଦେବ ରଥ)"
    ),
    MODERN_POETRY(
        titleEn = "Modern Odia Poetry",
        titleOr = "ଆଧୁନିକ ଓଡ଼ିଆ କବିତା",
        syllabusFocus = "ରାଧାନାଥ ରାୟ, ମଧୁସୂଦନ ରାଓ, ଗଙ୍ଗାଧର ମେହେର, ସତ୍ୟବାଦୀ ଯୁଗ (ଗୋପବନ୍ଧୁ, ନୀଳକଣ୍ଠ, ଗୋଦାବରୀଶ), ସବୁଜ ଯୁଗ (କାଳିନ୍ଦୀଚରଣ, ଅନ୍ନଦାଶଙ୍କର), ପ୍ରଗତିବାଦୀ ଓ ଆଧୁନିକ କବିତା (ସଚ୍ଚି ରାଉତରାୟ, ରମାକାନ୍ତ ରଥ, ସୀତାକାନ୍ତ ମହାପାତ୍ର)"
    ),
    PROSE_DRAMA(
        titleEn = "Prose, Fiction & Drama",
        titleOr = "ଗଦ୍ୟ, ଉପନ୍ୟାସ, ଗଳ୍ପ ଓ ନାଟକ",
        syllabusFocus = "ଫକୀର ମୋହନ ସେନାପତି, ଗୋପୀନାଥ ମହାନ୍ତି, ସୁରେନ୍ଦ୍ର ମହାନ୍ତି, ମନୋଜ ଦାସ, କାହ୍ନୁଚରଣ ମହାନ୍ତି, କାଳିଚରଣ ପଟ୍ଟନାୟକ, ମନୋରଞ୍ଜନ ଦାସ, ଜଗନ୍ନାଥ ପ୍ରସାଦ ଦାସ"
    ),
    GRAMMAR_LINGUISTICS(
        titleEn = "Grammar & Linguistics",
        titleOr = "ଓଡ଼ିଆ ବ୍ୟାକରଣ ଓ ଭାଷାତତ୍ତ୍ୱ",
        syllabusFocus = "ଓଡ଼ିଆ ଭାଷାର ଉତ୍ପତ୍ତି ଓ କ୍ରମବିକାଶ, ଧ୍ୱନି ପରିବର୍ତ୍ତନ, ରୂପତତ୍ତ୍ୱ, ସନ୍ଧି, ସମାସ, କାରକ, ବିଭକ୍ତି, କୃଦନ୍ତ, ତଦ୍ଧିତ, ଛନ୍ଦ ଓ ଅଳଙ୍କାର"
    ),
    LITERARY_CRITICISM(
        titleEn = "Literary Criticism",
        titleOr = "ସାହିତ୍ୟ ତତ୍ତ୍ୱ ଓ ସମାଲୋଚନା",
        syllabusFocus = "ରସ, ଧ୍ୱନି, ରୀତି, ବକ୍ରୋକ୍ତି, ଔଚିତ୍ୟ ତତ୍ତ୍ୱ, ପାଶ୍ଚାତ୍ୟ ସାହିତ୍ୟ ସମାଲୋଚନା (ଆରିଷ୍ଟୋଟଲ୍, ଲଞ୍ଜାଇନସ୍, କ୍ଲାସିସିଜମ୍, ରୋମାଣ୍ଟିସିଜମ୍)"
    );

    companion object {
        fun fromKey(key: String): OdiaTopic =
            entries.firstOrNull { it.name == key } ?: FULL_SYLLABUS
    }
}

enum class TestDifficulty(val labelEn: String, val labelOr: String) {
    EASY("Easy", "ସହଜ"),
    MODERATE("Moderate", "ମଧ୍ୟମ"),
    HARD("CPET Hard", "କଠିନ");

    companion object {
        fun fromKey(key: String): TestDifficulty =
            entries.firstOrNull { it.name == key } ?: MODERATE
    }
}

enum class QuestionSourceMode(val label: String) {
    GEMINI_AI("Gemini AI Live"),
    OFFLINE_BANK("Offline Bank");

    companion object {
        fun fromKey(key: String): QuestionSourceMode =
            entries.firstOrNull { it.name == key } ?: GEMINI_AI
    }
}

data class Question(
    val id: String,
    val topicKey: String,
    val stem: String,
    val options: List<String>,
    val correctIndex: Int,
    val explanation: String,
    val topicTag: String
)

data class TestConfig(
    val topic: OdiaTopic = OdiaTopic.FULL_SYLLABUS,
    val difficulty: TestDifficulty = TestDifficulty.MODERATE,
    val questionCount: Int = 10,
    val negativeMarkingEnabled: Boolean = true,
    val sourceMode: QuestionSourceMode = QuestionSourceMode.GEMINI_AI
)

data class ActiveMockSession(
    val sessionId: String,
    val config: TestConfig,
    val questions: List<Question>,
    val durationSeconds: Int
)

data class CompletedTestSummary(
    val session: ActiveMockSession,
    val selectedAnswers: Map<Int, Int>,
    val correctCount: Int,
    val wrongCount: Int,
    val skippedCount: Int,
    val score: Double,
    val maxScore: Double,
    val timeSpentSeconds: Int
)

@Keep
@IgnoreExtraProperties
data class TestAttempt(
    @DocumentId val id: String = "",
    val userId: String = "",
    val topicKey: String = "",
    val topicTitleOr: String = "",
    val difficulty: String = TestDifficulty.MODERATE.name,
    val totalQuestions: Long = 0L,
    val correctCount: Long = 0L,
    val wrongCount: Long = 0L,
    val skippedCount: Long = 0L,
    val negativeMarkingEnabled: Boolean = true,
    val score: Double = 0.0,
    val maxScore: Double = 0.0,
    val timeSpentSeconds: Long = 0L,
    val sourceMode: String = QuestionSourceMode.GEMINI_AI.name,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class BookmarkedQuestion(
    @DocumentId val id: String = "",
    val userId: String = "",
    val topicKey: String = "",
    val topicTag: String = "",
    val stem: String = "",
    val options: List<String> = emptyList(),
    val correctIndex: Long = 0L,
    val explanation: String = "",
    val personalNote: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

sealed interface UiState<out T> {
    data object Idle : UiState<Nothing>
    data object Loading : UiState<Nothing>
    data class Success<T>(val data: T) : UiState<T>
    data class Error(val message: String) : UiState<Nothing>
}
