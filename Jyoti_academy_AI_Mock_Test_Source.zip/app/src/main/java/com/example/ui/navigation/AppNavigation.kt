package com.example.ui.navigation

import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.School
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.R
import com.example.core.auth.authStateFlow
import com.example.core.auth.signOutUser
import com.example.data.repository.MockTestRepository
import com.example.domain.model.QuestionSourceMode
import com.example.domain.model.UiState
import com.example.ui.screens.auth.AuthScreen
import com.example.ui.screens.bookmarks.BookmarksAndBankScreen
import com.example.ui.screens.history.HistoryScreen
import com.example.ui.screens.home.HomeScreen
import com.example.ui.screens.home.MainAppViewModel
import com.example.ui.screens.result.ResultScreen
import com.example.ui.screens.test.MockTestScreen
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth

private object AppRoutes {
    const val HOME = "home"
    const val HISTORY = "history"
    const val SAVED = "saved"
    const val ACTIVE_TEST = "active_test"
    const val RESULT = "result"
}

private data class TopTabItem(
    val route: String,
    val labelRes: Int,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
)

private val TOP_TABS = listOf(
    TopTabItem(
        route = AppRoutes.HOME,
        labelRes = R.string.nav_practice,
        selectedIcon = Icons.Filled.School,
        unselectedIcon = Icons.Outlined.School,
        testTag = "nav_tab_practice"
    ),
    TopTabItem(
        route = AppRoutes.HISTORY,
        labelRes = R.string.nav_history,
        selectedIcon = Icons.Filled.History,
        unselectedIcon = Icons.Outlined.History,
        testTag = "nav_tab_history"
    ),
    TopTabItem(
        route = AppRoutes.SAVED,
        labelRes = R.string.nav_saved,
        selectedIcon = Icons.Filled.Bookmark,
        unselectedIcon = Icons.Outlined.BookmarkBorder,
        testTag = "nav_tab_saved"
    )
)

@Composable
fun AppNavigation(auth: FirebaseAuth = Firebase.auth) {
    val currentUser by auth.authStateFlow()
        .collectAsStateWithLifecycle(initialValue = auth.currentUser)

    val user = currentUser
    if (user == null) {
        AuthScreen(onAuthSuccess = {})
    } else {
        key(user.uid) {
            AuthenticatedAppShell(
                currentUserId = user.uid,
                userDisplayName = user.displayName ?: user.email ?: "CPET Aspirant"
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AuthenticatedAppShell(
    currentUserId: String,
    userDisplayName: String
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }

    val viewModel: MainAppViewModel = viewModel(
        key = currentUserId,
        factory = viewModelFactory {
            initializer {
                val app = checkNotNull(this[APPLICATION_KEY]) {
                    "APPLICATION_KEY missing from CreationExtras"
                }
                MainAppViewModel(
                    repository = MockTestRepository(app),
                    currentUserId = currentUserId
                )
            }
        }
    )

    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    val testConfig by viewModel.testConfig.collectAsStateWithLifecycle()
    val generationState by viewModel.generationState.collectAsStateWithLifecycle()
    val examState by viewModel.examState.collectAsStateWithLifecycle()
    val completedSummary by viewModel.completedSummary.collectAsStateWithLifecycle()
    val cloudSaveState by viewModel.cloudSaveState.collectAsStateWithLifecycle()
    val attemptsState by viewModel.attemptsState.collectAsStateWithLifecycle()
    val bookmarksState by viewModel.bookmarksState.collectAsStateWithLifecycle()
    val topicCacheCounts by viewModel.topicCacheCounts.collectAsStateWithLifecycle()
    val totalCachedCount by viewModel.totalCachedCount.collectAsStateWithLifecycle()
    val actionMessage by viewModel.actionMessage.collectAsStateWithLifecycle()

    val bookmarkedIds = remember(bookmarksState) {
        when (val state = bookmarksState) {
            is UiState.Success -> state.data.map { it.id }.toSet()
            else -> emptySet()
        }
    }

    val snackbarHostState = remember { SnackbarHostState() }
    LaunchedEffect(actionMessage) {
        val msg = actionMessage
        if (!msg.isNullOrBlank()) {
            snackbarHostState.showSnackbar(msg)
            viewModel.consumeActionMessage()
        }
    }

    val isFullScreenExamFlow = currentRoute == AppRoutes.ACTIVE_TEST || currentRoute == AppRoutes.RESULT

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useNavigationRail = maxWidth >= 600.dp

        Scaffold(
            snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
            topBar = {
                if (!isFullScreenExamFlow) {
                    TopAppBar(
                        title = {
                            Text(
                                text = stringResource(R.string.app_name),
                                style = MaterialTheme.typography.titleLarge
                            )
                        },
                        actions = {
                            Text(
                                text = userDisplayName.substringBefore(" "),
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(end = 4.dp)
                            )
                            IconButton(
                                onClick = {
                                    viewModel.abandonExam()
                                    signOutUser(credentialManager, scope)
                                },
                                modifier = Modifier.testTag("sign_out_button")
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.Logout,
                                    contentDescription = stringResource(R.string.sign_out)
                                )
                            }
                        }
                    )
                }
            },
            bottomBar = {
                if (!isFullScreenExamFlow && !useNavigationRail) {
                    NavigationBar {
                        TOP_TABS.forEach { tab ->
                            val selected = navBackStackEntry?.destination?.hierarchy?.any {
                                it.route == tab.route
                            } == true
                            NavigationBarItem(
                                selected = selected,
                                onClick = {
                                    navController.navigate(tab.route) {
                                        popUpTo(navController.graph.findStartDestination().id) {
                                            saveState = true
                                        }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                        contentDescription = stringResource(tab.labelRes)
                                    )
                                },
                                label = { Text(stringResource(tab.labelRes)) },
                                modifier = Modifier.testTag(tab.testTag)
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (!isFullScreenExamFlow && useNavigationRail) {
                    NavigationRail {
                        TOP_TABS.forEach { tab ->
                            val selected = navBackStackEntry?.destination?.hierarchy?.any {
                                it.route == tab.route
                            } == true
                            NavigationRailItem(
                                selected = selected,
                                onClick = {
                                    navController.navigate(tab.route) {
                                        popUpTo(navController.graph.findStartDestination().id) {
                                            saveState = true
                                        }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                        contentDescription = stringResource(tab.labelRes)
                                    )
                                },
                                label = { Text(stringResource(tab.labelRes)) },
                                modifier = Modifier.testTag(tab.testTag)
                            )
                        }
                    }
                }

                NavHost(
                    navController = navController,
                    startDestination = AppRoutes.HOME,
                    modifier = Modifier.weight(1f)
                ) {
                    composable(AppRoutes.HOME) {
                        HomeScreen(
                            config = testConfig,
                            generationState = generationState,
                            topicCacheCounts = topicCacheCounts,
                            totalCachedCount = totalCachedCount,
                            onSelectTopic = viewModel::selectTopic,
                            onSelectDifficulty = viewModel::selectDifficulty,
                            onSelectCount = viewModel::selectQuestionCount,
                            onToggleNegativeMarking = viewModel::setNegativeMarking,
                            onStartAiTest = {
                                viewModel.startTest(QuestionSourceMode.GEMINI_AI) {
                                    navController.navigate(AppRoutes.ACTIVE_TEST)
                                }
                            },
                            onStartOfflineTest = {
                                viewModel.startTest(QuestionSourceMode.OFFLINE_BANK) {
                                    navController.navigate(AppRoutes.ACTIVE_TEST)
                                }
                            },
                            onDismissError = viewModel::clearGenerationError
                        )
                    }

                    composable(AppRoutes.HISTORY) {
                        HistoryScreen(
                            attemptsState = attemptsState,
                            onDeleteAttempt = viewModel::deleteTestAttempt
                        )
                    }

                    composable(AppRoutes.SAVED) {
                        BookmarksAndBankScreen(
                            bookmarksState = bookmarksState,
                            topicCacheCounts = topicCacheCounts,
                            totalCachedCount = totalCachedCount,
                            onSaveNote = viewModel::updateBookmarkNote,
                            onDeleteBookmark = viewModel::deleteBookmark,
                            onLaunchOfflineTopic = { topic ->
                                viewModel.startTest(
                                    sourceMode = QuestionSourceMode.OFFLINE_BANK,
                                    topicOverride = topic
                                ) {
                                    navController.navigate(AppRoutes.ACTIVE_TEST)
                                }
                            },
                            onClearOfflineBank = viewModel::clearOfflineBank
                        )
                    }

                    composable(AppRoutes.ACTIVE_TEST) {
                        MockTestScreen(
                            examState = examState,
                            bookmarkedIds = bookmarkedIds,
                            bookmarkIdForQuestion = MockTestRepository::bookmarkDocId,
                            onSelectAnswer = viewModel::selectAnswer,
                            onClearAnswer = viewModel::clearAnswer,
                            onToggleReviewFlag = viewModel::toggleMarkForReview,
                            onToggleBookmark = viewModel::toggleBookmark,
                            onJumpToQuestion = viewModel::jumpToQuestion,
                            onPrevious = viewModel::previousQuestion,
                            onNext = viewModel::nextQuestion,
                            onSubmitTest = {
                                viewModel.submitExam {
                                    navController.navigate(AppRoutes.RESULT) {
                                        popUpTo(AppRoutes.ACTIVE_TEST) { inclusive = true }
                                    }
                                }
                            },
                            onAbandonTest = {
                                viewModel.abandonExam()
                                navController.popBackStack()
                            }
                        )
                    }

                    composable(AppRoutes.RESULT) {
                        ResultScreen(
                            summary = completedSummary,
                            cloudSaveState = cloudSaveState,
                            bookmarkedIds = bookmarkedIds,
                            bookmarkIdForQuestion = MockTestRepository::bookmarkDocId,
                            onToggleBookmark = viewModel::toggleBookmark,
                            onDoneToHome = {
                                navController.popBackStack(AppRoutes.HOME, inclusive = false)
                            }
                        )
                    }
                }
            }
        }
    }
}
