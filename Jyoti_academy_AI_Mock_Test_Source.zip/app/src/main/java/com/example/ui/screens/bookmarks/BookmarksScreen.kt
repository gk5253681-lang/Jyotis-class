package com.example.ui.screens.bookmarks

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BookmarkAdded
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.OfflineBolt
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.domain.model.BookmarkedQuestion
import com.example.domain.model.OdiaTopic
import com.example.domain.model.UiState
import com.example.ui.theme.CorrectGreenContainer

@Composable
fun BookmarksAndBankScreen(
    bookmarksState: UiState<List<BookmarkedQuestion>>,
    topicCacheCounts: Map<String, Int>,
    totalCachedCount: Int,
    onSaveNote: (String, String) -> Unit,
    onDeleteBookmark: (String) -> Unit,
    onLaunchOfflineTopic: (OdiaTopic) -> Unit,
    onClearOfflineBank: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedSegment by remember { mutableIntStateOf(0) }
    var editingBookmark by remember { mutableStateOf<BookmarkedQuestion?>(null) }
    var noteDraft by remember { mutableStateOf("") }

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 720.dp)
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                SegmentedButton(
                    selected = selectedSegment == 0,
                    onClick = { selectedSegment = 0 },
                    shape = SegmentedButtonDefaults.itemShape(index = 0, count = 2),
                    modifier = Modifier.testTag("segment_bookmarks")
                ) {
                    Text("Bookmarks")
                }
                SegmentedButton(
                    selected = selectedSegment == 1,
                    onClick = { selectedSegment = 1 },
                    shape = SegmentedButtonDefaults.itemShape(index = 1, count = 2),
                    modifier = Modifier.testTag("segment_offline_bank")
                ) {
                    Text("Offline Bank ($totalCachedCount)")
                }
            }

            if (selectedSegment == 0) {
                when (bookmarksState) {
                    UiState.Loading, UiState.Idle -> {
                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            CircularProgressIndicator()
                        }
                    }

                    is UiState.Error -> {
                        Text(
                            text = bookmarksState.message,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.error,
                            modifier = Modifier.padding(16.dp)
                        )
                    }

                    is UiState.Success -> {
                        val items = bookmarksState.data
                        if (items.isEmpty()) {
                            EmptyBookmarksView()
                        } else {
                            LazyColumn(
                                contentPadding = PaddingValues(vertical = 4.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                items(items, key = { it.id }) { bm ->
                                    BookmarkItemCard(
                                        bookmark = bm,
                                        onEditNote = {
                                            editingBookmark = bm
                                            noteDraft = bm.personalNote
                                        },
                                        onDelete = { onDeleteBookmark(bm.id) }
                                    )
                                }
                                item { Spacer(modifier = Modifier.height(16.dp)) }
                            }
                        }
                    }
                }
            } else {
                OfflineBankView(
                    topicCacheCounts = topicCacheCounts,
                    totalCachedCount = totalCachedCount,
                    onLaunchOfflineTopic = onLaunchOfflineTopic,
                    onClearOfflineBank = onClearOfflineBank
                )
            }
        }
    }

    editingBookmark?.let { target ->
        AlertDialog(
            onDismissRequest = { editingBookmark = null },
            title = { Text("Personal Study Note") },
            text = {
                OutlinedTextField(
                    value = noteDraft,
                    onValueChange = { if (it.length <= 500) noteDraft = it },
                    label = { Text("Note (up to 500 chars)") },
                    minLines = 3,
                    maxLines = 5,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("bookmark_note_input")
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        onSaveNote(target.id, noteDraft)
                        editingBookmark = null
                    },
                    modifier = Modifier.testTag("save_bookmark_note_button")
                ) {
                    Text("Save Note")
                }
            },
            dismissButton = {
                TextButton(onClick = { editingBookmark = null }) {
                    Text(stringResource(R.string.cancel))
                }
            }
        )
    }
}

@Composable
private fun EmptyBookmarksView() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = Icons.Filled.BookmarkAdded,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.secondary,
            modifier = Modifier.size(56.dp)
        )
        Spacer(modifier = Modifier.height(10.dp))
        Text(
            text = "No Bookmarked Questions",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = "Tap the bookmark icon during any mock test or review to save important Odia MCQs and personal notes.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun BookmarkItemCard(
    bookmark: BookmarkedQuestion,
    onEditNote: () -> Unit,
    onDelete: () -> Unit
) {
    val optionLabels = listOf("କ", "ଖ", "ଗ", "ଘ")
    val correctIdx = bookmark.correctIndex.toInt().coerceIn(0, 3)

    OutlinedCard(
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        colors = CardDefaults.outlinedCardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    color = MaterialTheme.colorScheme.secondaryContainer,
                    shape = RoundedCornerShape(50)
                ) {
                    Text(
                        text = bookmark.topicTag,
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSecondaryContainer,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
                Row {
                    IconButton(
                        onClick = onEditNote,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("edit_note_${bookmark.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.EditNote,
                            contentDescription = stringResource(R.string.cd_edit_note)
                        )
                    }
                    IconButton(
                        onClick = onDelete,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("delete_bookmark_${bookmark.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.DeleteOutline,
                            contentDescription = "Delete bookmark"
                        )
                    }
                }
            }

            Text(
                text = bookmark.stem,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )

            bookmark.options.forEachIndexed { idx, opt ->
                val isAnswer = idx == correctIdx
                Surface(
                    color = if (isAnswer) CorrectGreenContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "(${optionLabels.getOrElse(idx) { "${idx + 1}" }}) $opt",
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                    )
                }
            }

            if (bookmark.explanation.isNotBlank()) {
                Text(
                    text = "ବ୍ୟାଖ୍ୟା: ${bookmark.explanation}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            if (bookmark.personalNote.isNotBlank()) {
                Surface(
                    color = MaterialTheme.colorScheme.tertiaryContainer,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Note: ${bookmark.personalNote}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onTertiaryContainer,
                        modifier = Modifier.padding(10.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun OfflineBankView(
    topicCacheCounts: Map<String, Int>,
    totalCachedCount: Int,
    onLaunchOfflineTopic: (OdiaTopic) -> Unit,
    onClearOfflineBank: () -> Unit
) {
    LazyColumn(
        contentPadding = PaddingValues(vertical = 4.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Local Room Question Bank",
                            style = MaterialTheme.typography.titleSmall
                        )
                        Text(
                            text = "$totalCachedCount generated questions saved on-device for instant offline practice.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    if (totalCachedCount > 0) {
                        OutlinedButton(
                            onClick = onClearOfflineBank,
                            modifier = Modifier.testTag("clear_offline_bank_button")
                        ) {
                            Text("Clear")
                        }
                    }
                }
            }
        }

        items(OdiaTopic.entries, key = { it.name }) { topic ->
            val count = if (topic == OdiaTopic.FULL_SYLLABUS) {
                totalCachedCount
            } else {
                topicCacheCounts[topic.name] ?: 0
            }
            OutlinedCard(
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                colors = CardDefaults.outlinedCardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = topic.titleOr,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "$count questions cached",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Button(
                        onClick = { onLaunchOfflineTopic(topic) },
                        enabled = count > 0,
                        modifier = Modifier.testTag("launch_offline_${topic.name.lowercase()}")
                    ) {
                        Icon(
                            imageVector = if (count > 0) Icons.Filled.PlayArrow else Icons.Filled.OfflineBolt,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Text("Practice")
                    }
                }
            }
        }
        item { Spacer(modifier = Modifier.height(16.dp)) }
    }
}
