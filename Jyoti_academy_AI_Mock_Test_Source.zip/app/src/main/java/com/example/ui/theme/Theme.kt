package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val LightColorScheme = lightColorScheme(
    primary = KalingaIndigo,
    onPrimary = Color.White,
    primaryContainer = KalingaIndigoContainer,
    onPrimaryContainer = OnKalingaIndigoContainer,
    secondary = SaffronTerracotta,
    onSecondary = Color.White,
    secondaryContainer = SaffronContainer,
    onSecondaryContainer = OnSaffronContainer,
    tertiary = KonarkGold,
    onTertiary = Color.White,
    tertiaryContainer = KonarkGoldContainer,
    onTertiaryContainer = OnKonarkGoldContainer,
    background = ParchmentBackground,
    onBackground = InkPrimary,
    surface = IvorySurface,
    onSurface = InkPrimary,
    surfaceVariant = SandstoneSurfaceVariant,
    onSurfaceVariant = InkSecondary,
    outline = WarmOutline,
    outlineVariant = WarmOutlineVariant,
    error = WrongRed,
    onError = Color.White,
    errorContainer = WrongRedContainer,
    onErrorContainer = WrongRed
)

private val DarkColorScheme = darkColorScheme(
    primary = DarkIndigoPrimary,
    onPrimary = OnKalingaIndigoContainer,
    primaryContainer = DarkIndigoContainer,
    onPrimaryContainer = Color(0xFFE2E9FA),
    secondary = DarkAmberSecondary,
    onSecondary = Color(0xFF2B1800),
    secondaryContainer = DarkAmberContainer,
    onSecondaryContainer = Color(0xFFFFE5B4),
    tertiary = Color(0xFFFDBA74),
    onTertiary = Color(0xFF331800),
    background = DarkSlateBackground,
    onBackground = Color(0xFFF1F5F9),
    surface = DarkSlateSurface,
    onSurface = Color(0xFFF1F5F9),
    surfaceVariant = DarkSlateSurfaceVariant,
    onSurfaceVariant = Color(0xFFCBD5E1),
    outline = Color(0xFF475569),
    outlineVariant = Color(0xFF2D3B55),
    error = Color(0xFFFCA5A5),
    onError = Color(0xFF450A0A),
    errorContainer = Color(0xFF7F1D1D),
    onErrorContainer = Color(0xFFFEE2E2)
)

private val AppShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp)
)

@Composable
fun OdiaPgMockTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = AppTypography,
        shapes = AppShapes,
        content = content
    )
}
