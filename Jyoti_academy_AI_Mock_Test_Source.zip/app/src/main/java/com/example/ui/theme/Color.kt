package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Kalinga Scholarly Manuscript Palette (Light)
val KalingaIndigo = Color(0xFF1B2A4A)
val KalingaIndigoContainer = Color(0xFFD9E2F5)
val OnKalingaIndigoContainer = Color(0xFF0E182D)

val SaffronTerracotta = Color(0xFFC85A17)
val SaffronContainer = Color(0xFFFFDFCC)
val OnSaffronContainer = Color(0xFF3D1700)

val KonarkGold = Color(0xFFB45309)
val KonarkGoldContainer = Color(0xFFFEF3C7)
val OnKonarkGoldContainer = Color(0xFF3A1C00)

val ParchmentBackground = Color(0xFFFAF7F2)
val IvorySurface = Color(0xFFFFFFFF)
val SandstoneSurfaceVariant = Color(0xFFF1EAE0)
val WarmOutline = Color(0xFFD6CBBF)
val WarmOutlineVariant = Color(0xFFE7DFD5)

val InkPrimary = Color(0xFF1A1C22)
val InkSecondary = Color(0xFF545863)

// Dark Theme Counterparts
val DarkSlateBackground = Color(0xFF0E1422)
val DarkSlateSurface = Color(0xFF162033)
val DarkSlateSurfaceVariant = Color(0xFF212E45)
val DarkIndigoPrimary = Color(0xFFADC6FF)
val DarkIndigoContainer = Color(0xFF283E6B)
val DarkAmberSecondary = Color(0xFFFBBF24)
val DarkAmberContainer = Color(0xFF533304)

// Semantic Exam Status Colors
val CorrectGreen = Color(0xFF15803D)
val CorrectGreenContainer = Color(0xFFDCFCE7)
val WrongRed = Color(0xFFB91C1C)
val WrongRedContainer = Color(0xFFFEE2E2)
val ReviewPurple = Color(0xFF7E22CE)
val ReviewPurpleContainer = Color(0xFFF3E8FF)
