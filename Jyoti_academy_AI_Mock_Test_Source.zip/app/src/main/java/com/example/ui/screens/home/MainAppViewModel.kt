package com.example.ui.screens.home

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.repository.MockTestRepository
import com.example.domain.model.ActiveMockSession
import com.example.domain.model.BookmarkedQuestion
import com.example.domain.model.CompletedTestSummary
import com.example.domain.model.OdiaTopic
import com.example.domain.model.Question
import com.example.domain.model.QuestionSourceMode
import com.example.domain.model.TestAttempt
import com.example.domain.model.TestConfig
import com.example.domain.model.TestDifficulty
import com.example.domain.model.UiState
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

private const val TAG = "MainAppVM"
private const val STOP_TIMEOUT_MILLIS = 5000L

data class ActiveExamUiState(
    val session: ActiveMockSession? = null,
    val currentQuestionIndex: Int = 0,
    val selectedAnswers: Map<Int, Int> = emptyMap(),
    val markedForReview: Set<Int> = emptySet(),
    val remainingSeconds: Int = 0,
    val isSubmitting: Boolean = false
)

class MainAppViewModel(
    private val repository: MockTestRepository,
    val currentUserId: String
) : ViewModel() {

    private val _testConfig = MutableStateFlow(TestConfig())
    val testConfig: StateFlow<TestConfig> = _testConfig.asStateFlow()

    private val _generationState = MutableStateFlow<UiState<ActiveMockSession>>(UiState.Idle)
    val generationState: StateFlow<UiState<ActiveMockSession>> = _generationState.asStateFlow()

    private val _examState = MutableStateFlow(ActiveExamUiState())
    val examState: StateFlow<ActiveExamUiState> = _examState.asStateFlow()

    private val _completedSummary = MutableStateFlow<CompletedTestSummary?>(null)
    val completedSummary: StateFlow<CompletedTestSummary?> = _completedSummary.asStateFlow()

    private val _cloudSaveState = MutableStateFlow<UiState<String>>(UiState.Idle)
    val cloudSaveState: StateFlow<UiState<String>> = _cloudSaveState.asStateFlow()

    private val _actionMessage = MutableStateFlow<String?>(null)
    val actionMessage: StateFlow<String?> = _actionMessage.asStateFlow()

    private var timerJob: Job? = null

    val attemptsState: StateFlow<UiState<List<TestAttempt>>> =
        repository.observeTestAttempts(currentUserId)
            .map<List<TestAttempt>, UiState<List<TestAttempt>>> { UiState.Success(it) }
            .catch { error ->
                val firestoreError = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreError == null && error is CancellationException) throw error
                val rootError = firestoreError ?: error
                Log.w(TAG, "Error observing testAttempts", rootError)
                emit(UiState.Error(rootError.localizedMessage ?: "Failed to load test history."))
            }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
                initialValue = UiState.Loading
            )

    val bookmarksState: StateFlow<UiState<List<BookmarkedQuestion>>> =
        repository.observeBookmarks(currentUserId)
            .map<List<BookmarkedQuestion>, UiState<List<BookmarkedQuestion>>> { UiState.Success(it) }
            .catch { error ->
                val firestoreError = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreError == null && error is CancellationException) throw error
                val rootError = firestoreError ?: error
                Log.w(TAG, "Error observing bookmarks", rootError)
                emit(UiState.Error(rootError.localizedMessage ?: "Failed to load bookmarks."))
            }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
                initialValue = UiState.Loading
            )

    val topicCacheCounts: StateFlow<Map<String, Int>> =
        repository.observeCachedTopicCounts()
            .map { counts -> counts.associate { it.topicKey to it.count } }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
                initialValue = emptyMap()
            )

    val totalCachedCount: StateFlow<Int> =
        repository.observeTotalCachedCount()
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
                initialValue = 0
            )

    fun selectTopic(topic: OdiaTopic) {
        _testConfig.update { it.copy(topic = topic) }
    }

    fun selectDifficulty(difficulty: TestDifficulty) {
        _testConfig.update { it.copy(difficulty = difficulty) }
    }

    fun selectQuestionCount(count: Int) {
        _testConfig.update { it.copy(questionCount = count.coerceIn(5, 20)) }
    }

    fun setNegativeMarking(enabled: Boolean) {
        _testConfig.update { it.copy(negativeMarkingEnabled = enabled) }
    }

    fun startTest(
        sourceMode: QuestionSourceMode,
        topicOverride: OdiaTopic? = null,
        onReady: () -> Unit
    ) {
        val activeConfig = _testConfig.value.copy(
            topic = topicOverride ?: _testConfig.value.topic,
            sourceMode = sourceMode
        )
        _testConfig.value = activeConfig
        viewModelScope.launch {
            _generationState.value = UiState.Loading
            try {
                val session = repository.generateMockSession(activeConfig)
                beginExamSession(session)
                _generationState.value = UiState.Success(session)
                onReady()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Failed to start mock test (${sourceMode.name})", e)
                _generationState.value = UiState.Error(
                    e.localizedMessage ?: "Failed to generate Odia mock questions."
                )
            }
        }
    }

    fun clearGenerationError() {
        if (_generationState.value is UiState.Error || _generationState.value is UiState.Success) {
            _generationState.value = UiState.Idle
        }
    }

    private fun beginExamSession(session: ActiveMockSession) {
        timerJob?.cancel()
        _completedSummary.value = null
        _cloudSaveState.value = UiState.Idle
        _examState.value = ActiveExamUiState(
            session = session,
            currentQuestionIndex = 0,
            selectedAnswers = emptyMap(),
            markedForReview = emptySet(),
            remainingSeconds = session.durationSeconds,
            isSubmitting = false
        )
        timerJob = viewModelScope.launch {
            while (_examState.value.remainingSeconds > 0) {
                delay(1000L)
                val next = (_examState.value.remainingSeconds - 1).coerceAtLeast(0)
                _examState.update { it.copy(remainingSeconds = next) }
                if (next == 0) {
                    submitExam(onSubmitted = {})
                    break
                }
            }
        }
    }

    fun selectAnswer(questionIndex: Int, optionIndex: Int) {
        _examState.update { state ->
            val updated = state.selectedAnswers.toMutableMap()
            updated[questionIndex] = optionIndex
            state.copy(selectedAnswers = updated)
        }
    }

    fun clearAnswer(questionIndex: Int) {
        _examState.update { state ->
            val updated = state.selectedAnswers.toMutableMap()
            updated.remove(questionIndex)
            state.copy(selectedAnswers = updated)
        }
    }

    fun toggleMarkForReview(questionIndex: Int) {
        _examState.update { state ->
            val updated = state.markedForReview.toMutableSet()
            if (!updated.add(questionIndex)) {
                updated.remove(questionIndex)
            }
            state.copy(markedForReview = updated)
        }
    }

    fun jumpToQuestion(index: Int) {
        val total = _examState.value.session?.questions?.size ?: return
        if (index in 0 until total) {
            _examState.update { it.copy(currentQuestionIndex = index) }
        }
    }

    fun nextQuestion() {
        val state = _examState.value
        val total = state.session?.questions?.size ?: return
        if (state.currentQuestionIndex < total - 1) {
            _examState.update { it.copy(currentQuestionIndex = it.currentQuestionIndex + 1) }
        }
    }

    fun previousQuestion() {
        val state = _examState.value
        if (state.currentQuestionIndex > 0) {
            _examState.update { it.copy(currentQuestionIndex = it.currentQuestionIndex - 1) }
        }
    }

    fun abandonExam() {
        timerJob?.cancel()
        _examState.value = ActiveExamUiState()
        _generationState.value = UiState.Idle
    }

    fun submitExam(onSubmitted: () -> Unit) {
        val current = _examState.value
        val session = current.session ?: return
        if (current.isSubmitting) return

        timerJob?.cancel()
        _examState.update { it.copy(isSubmitting = true) }

        var correct = 0
        var wrong = 0
        var skipped = 0
        session.questions.forEachIndexed { idx, question ->
            val chosen = current.selectedAnswers[idx]
            when {
                chosen == null -> skipped++
                chosen == question.correctIndex -> correct++
                else -> wrong++
            }
        }

        val penalty = if (session.config.negativeMarkingEnabled) wrong * 0.25 else 0.0
        val rawScore = (correct * 1.0) - penalty
        val score = (Math.round(rawScore * 100.0) / 100.0)
        val maxScore = session.questions.size * 1.0
        val timeSpent = (session.durationSeconds - current.remainingSeconds)
            .coerceIn(0, session.durationSeconds)

        val summary = CompletedTestSummary(
            session = session,
            selectedAnswers = current.selectedAnswers,
            correctCount = correct,
            wrongCount = wrong,
            skippedCount = skipped,
            score = score,
            maxScore = maxScore,
            timeSpentSeconds = timeSpent
        )
        _completedSummary.value = summary
        _generationState.value = UiState.Idle
        onSubmitted()

        viewModelScope.launch {
            _cloudSaveState.value = UiState.Loading
            val result = repository.saveTestAttempt(currentUserId, summary)
            result.onSuccess { docId ->
                _cloudSaveState.value = UiState.Success(docId)
            }.onFailure { err ->
                _cloudSaveState.value = UiState.Error(
                    err.localizedMessage ?: "Saved locally; cloud sync failed."
                )
            }
        }
    }

    fun toggleBookmark(question: Question) {
        viewModelScope.launch {
            val result = repository.toggleBookmark(currentUserId, question)
            result.onSuccess { isSaved ->
                _actionMessage.value = if (isSaved) {
                    "Question saved to Bookmarks"
                } else {
                    "Removed from Bookmarks"
                }
            }.onFailure { err ->
                _actionMessage.value = err.localizedMessage ?: "Could not update bookmark."
            }
        }
    }

    fun updateBookmarkNote(bookmarkId: String, note: String) {
        viewModelScope.launch {
            val result = repository.updateBookmarkNote(currentUserId, bookmarkId, note)
            result.onSuccess {
                _actionMessage.value = "Study note saved"
            }.onFailure { err ->
                _actionMessage.value = err.localizedMessage ?: "Failed to save study note."
            }
        }
    }

    fun deleteBookmark(bookmarkId: String) {
        viewModelScope.launch {
            val result = repository.deleteBookmark(currentUserId, bookmarkId)
            result.onSuccess {
                _actionMessage.value = "Bookmark removed"
            }.onFailure { err ->
                _actionMessage.value = err.localizedMessage ?: "Failed to remove bookmark."
            }
        }
    }

    fun deleteTestAttempt(attemptId: String) {
        viewModelScope.launch {
            val result = repository.deleteTestAttempt(currentUserId, attemptId)
            result.onSuccess {
                _actionMessage.value = "Test attempt deleted"
            }.onFailure { err ->
                _actionMessage.value = err.localizedMessage ?: "Failed to delete attempt."
            }
        }
    }

    fun clearOfflineBank() {
        viewModelScope.launch {
            try {
                repository.clearOfflineBank()
                _actionMessage.value = "Offline question bank cleared"
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _actionMessage.value = e.localizedMessage ?: "Failed to clear offline bank."
            }
        }
    }

    fun consumeActionMessage() {
        _actionMessage.value = null
    }

    override fun onCleared() {
        super.onCleared()
        timerJob?.cancel()
    }
}
