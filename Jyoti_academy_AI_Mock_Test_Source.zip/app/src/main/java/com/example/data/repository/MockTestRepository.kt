package com.example.data.repository

import android.content.Context
import com.example.R
import com.example.core.firebase.OperationType
import com.example.core.firebase.handleFirestoreError
import com.example.data.local.AppDatabase
import com.example.data.local.CachedQuestionDao
import com.example.data.local.CachedQuestionEntity
import com.example.data.local.TopicCacheCount
import com.example.data.remote.GeminiOdiaQuestionService
import com.example.domain.model.ActiveMockSession
import com.example.domain.model.BookmarkedQuestion
import com.example.domain.model.CompletedTestSummary
import com.example.domain.model.OdiaTopic
import com.example.domain.model.Question
import com.example.domain.model.QuestionSourceMode
import com.example.domain.model.TestAttempt
import com.example.domain.model.TestConfig
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import java.security.MessageDigest
import java.util.UUID

class MockTestRepository(
    private val db: FirebaseFirestore,
    private val cachedQuestionDao: CachedQuestionDao,
    private val geminiService: GeminiOdiaQuestionService = GeminiOdiaQuestionService(),
    private val auth: FirebaseAuth = Firebase.auth
) {
    constructor(context: Context) : this(
        db = FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        ),
        cachedQuestionDao = AppDatabase.getInstance(context.applicationContext).cachedQuestionDao()
    )

    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("Please sign in with Google to sync your progress.")
    }

    suspend fun generateMockSession(config: TestConfig): ActiveMockSession {
        val questions = when (config.sourceMode) {
            QuestionSourceMode.GEMINI_AI -> {
                val generated = geminiService.generateQuestions(
                    topic = config.topic,
                    difficulty = config.difficulty,
                    count = config.questionCount
                )
                cachedQuestionDao.insertAll(
                    generated.map { CachedQuestionEntity.fromDomain(it, config.difficulty.name) }
                )
                generated
            }

            QuestionSourceMode.OFFLINE_BANK -> {
                val cachedEntities = if (config.topic == OdiaTopic.FULL_SYLLABUS) {
                    cachedQuestionDao.getAnyTopic(config.questionCount)
                } else {
                    cachedQuestionDao.getByTopic(config.topic.name, config.questionCount)
                }
                if (cachedEntities.isEmpty()) {
                    throw IllegalStateException(
                        "No offline questions cached for ${config.topic.titleEn} yet. Generate an AI test once to build your offline bank."
                    )
                }
                cachedQuestionDao.incrementAttempted(cachedEntities.map { it.id })
                cachedEntities.map { it.toDomain() }
            }
        }

        return ActiveMockSession(
            sessionId = UUID.randomUUID().toString(),
            config = config,
            questions = questions,
            durationSeconds = questions.size * 60
        )
    }

    fun observeCachedTopicCounts(): Flow<List<TopicCacheCount>> =
        cachedQuestionDao.observeTopicCounts()

    fun observeTotalCachedCount(): Flow<Int> =
        cachedQuestionDao.observeTotalCount()

    suspend fun clearOfflineBank() {
        cachedQuestionDao.clearAll()
    }

    fun observeTestAttempts(userId: String): Flow<List<TestAttempt>> = flow {
        val activeUid = auth.currentUser?.uid
        if (activeUid.isNullOrBlank() || activeUid != userId) {
            emit(emptyList())
            return@flow
        }
        val path = "users/$userId/testAttempts"
        emitAll(
            db.collection("users").document(userId).collection("testAttempts")
                .orderBy("createdAt", Query.Direction.DESCENDING)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        TestAttempt::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    )
                }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val exceptionToLog = firestoreError ?: (error as? Exception)
                    if (exceptionToLog != null && auth.currentUser?.uid == userId) {
                        handleFirestoreError(exceptionToLog, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    suspend fun saveTestAttempt(userId: String, summary: CompletedTestSummary): Result<String> {
        val docRef = db.collection("users").document(userId).collection("testAttempts").document()
        val docPath = docRef.path
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Signed-in user changed; refusing cross-user write." }
            val config = summary.session.config
            val total = summary.session.questions.size.coerceIn(1, 100)
            val correct = summary.correctCount.coerceIn(0, total)
            val wrong = summary.wrongCount.coerceIn(0, total - correct)
            val skipped = (total - correct - wrong).coerceAtLeast(0)

            val payload = mapOf(
                "userId" to uid,
                "topicKey" to config.topic.name.take(64),
                "topicTitleOr" to config.topic.titleOr.take(160),
                "difficulty" to config.difficulty.name,
                "totalQuestions" to total.toLong(),
                "correctCount" to correct.toLong(),
                "wrongCount" to wrong.toLong(),
                "skippedCount" to skipped.toLong(),
                "negativeMarkingEnabled" to config.negativeMarkingEnabled,
                "score" to summary.score,
                "maxScore" to summary.maxScore.coerceAtLeast(1.0),
                "timeSpentSeconds" to summary.timeSpentSeconds.coerceIn(0, 14400).toLong(),
                "sourceMode" to config.sourceMode.name,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            docRef.set(payload).await()
            Result.success(docRef.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docPath)
            Result.failure(e)
        }
    }

    suspend fun deleteTestAttempt(userId: String, attemptId: String): Result<Unit> {
        val docPath = "users/$userId/testAttempts/$attemptId"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Signed-in user changed; refusing cross-user delete." }
            require(attemptId.isNotBlank()) { "Attempt ID cannot be blank." }
            db.collection("users").document(userId)
                .collection("testAttempts").document(attemptId)
                .delete()
                .await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docPath)
            Result.failure(e)
        }
    }

    fun observeBookmarks(userId: String): Flow<List<BookmarkedQuestion>> = flow {
        val activeUid = auth.currentUser?.uid
        if (activeUid.isNullOrBlank() || activeUid != userId) {
            emit(emptyList())
            return@flow
        }
        val path = "users/$userId/bookmarks"
        emitAll(
            db.collection("users").document(userId).collection("bookmarks")
                .orderBy("createdAt", Query.Direction.DESCENDING)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        BookmarkedQuestion::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    )
                }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val exceptionToLog = firestoreError ?: (error as? Exception)
                    if (exceptionToLog != null && auth.currentUser?.uid == userId) {
                        handleFirestoreError(exceptionToLog, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    suspend fun toggleBookmark(userId: String, question: Question): Result<Boolean> {
        val bookmarkId = bookmarkDocId(question)
        val docPath = "users/$userId/bookmarks/$bookmarkId"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Signed-in user changed; refusing cross-user write." }
            val docRef = db.collection("users").document(userId)
                .collection("bookmarks").document(bookmarkId)
            val existingSnap = docRef.get().await()
            if (existingSnap.exists()) {
                docRef.delete().await()
                Result.success(false)
            } else {
                val safeOptions = question.options.take(4).map { it.take(500).ifBlank { "—" } }
                require(safeOptions.size == 4) { "Question must have 4 options." }
                val payload = mapOf(
                    "userId" to uid,
                    "topicKey" to question.topicKey.take(64).ifBlank { OdiaTopic.FULL_SYLLABUS.name },
                    "topicTag" to question.topicTag.take(160).ifBlank { "ଓଡ଼ିଆ ସାହିତ୍ୟ" },
                    "stem" to question.stem.take(2000).ifBlank { "ପ୍ରଶ୍ନ" },
                    "options" to safeOptions,
                    "correctIndex" to question.correctIndex.coerceIn(0, 3).toLong(),
                    "explanation" to question.explanation.take(3000),
                    "personalNote" to "",
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                docRef.set(payload).await()
                Result.success(true)
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docPath)
            Result.failure(e)
        }
    }

    suspend fun updateBookmarkNote(
        userId: String,
        bookmarkId: String,
        personalNote: String
    ): Result<Unit> {
        val docPath = "users/$userId/bookmarks/$bookmarkId"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Signed-in user changed; refusing cross-user update." }
            require(bookmarkId.isNotBlank()) { "Bookmark ID cannot be blank." }
            val trimmedNote = personalNote.trim().take(500)
            db.collection("users").document(userId)
                .collection("bookmarks").document(bookmarkId)
                .update(
                    mapOf(
                        "personalNote" to trimmedNote,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
                .await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docPath)
            Result.failure(e)
        }
    }

    suspend fun deleteBookmark(userId: String, bookmarkId: String): Result<Unit> {
        val docPath = "users/$userId/bookmarks/$bookmarkId"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Signed-in user changed; refusing cross-user delete." }
            require(bookmarkId.isNotBlank()) { "Bookmark ID cannot be blank." }
            db.collection("users").document(userId)
                .collection("bookmarks").document(bookmarkId)
                .delete()
                .await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docPath)
            Result.failure(e)
        }
    }

    companion object {
        fun bookmarkDocId(question: Question): String {
            val bytes = MessageDigest.getInstance("SHA-256")
                .digest(question.stem.trim().toByteArray(Charsets.UTF_8))
            return "bm_" + bytes.take(16).joinToString("") { "%02x".format(it) }
        }
    }
}
