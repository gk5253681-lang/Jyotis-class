package com.example.data.remote

import android.util.Log
import com.example.domain.model.OdiaTopic
import com.example.domain.model.Question
import com.example.domain.model.TestDifficulty
import com.google.firebase.Firebase
import com.google.firebase.ai.GenerativeModel
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Schema
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.withTimeout
import org.json.JSONObject
import java.util.UUID

private const val TAG = "GeminiOdiaQuestions"
private const val GENERATION_TIMEOUT_MS = 60_000L

class GeminiOdiaQuestionService {

    private val quizSchema by lazy {
        Schema.obj(
            properties = mapOf(
                "questions" to Schema.array(
                    items = Schema.obj(
                        properties = mapOf(
                            "stem" to Schema.string(
                                description = "Multiple-choice question stem written in standard Odia Unicode script"
                            ),
                            "options" to Schema.array(
                                items = Schema.string(description = "Distinct MCQ option in Odia Unicode script"),
                                description = "Exactly 4 distinct options"
                            ),
                            "correctIndex" to Schema.integer(
                                description = "Zero-based index of the correct option: 0, 1, 2, or 3"
                            ),
                            "explanation" to Schema.string(
                                description = "Concise 1-2 sentence explanation (ବ୍ୟାଖ୍ୟା) in Odia Unicode"
                            ),
                            "topicTag" to Schema.string(
                                description = "Specific Odia sub-topic name in Odia Unicode"
                            )
                        )
                    ),
                    description = "Generated CPET MA Odia multiple-choice questions"
                )
            )
        )
    }

    private val jsonConfig by lazy {
        generationConfig {
            temperature = 0.35f
            responseMimeType = "application/json"
            responseSchema = quizSchema
        }
    }

    private val primaryModel: GenerativeModel by lazy {
        Firebase.ai(backend = com.google.firebase.ai.type.GenerativeBackend.googleAI()).generativeModel(
            modelName = "gemini-2.5-flash",
            generationConfig = jsonConfig
        )
    }

    private val fallbackModel: GenerativeModel by lazy {
        Firebase.ai(backend = com.google.firebase.ai.type.GenerativeBackend.googleAI()).generativeModel(
            modelName = "gemini-2.5-flash-lite",
            generationConfig = jsonConfig
        )
    }

    suspend fun generateQuestions(
        topic: OdiaTopic,
        difficulty: TestDifficulty,
        count: Int
    ): List<Question> {
        require(count in 1..100) { "Choose between 1 and 100 questions per test." }
        val all = mutableListOf<Question>()
        val seen = mutableSetOf<String>()
        var lastException: Exception? = null
        // Generate in manageable batches: single huge JSON responses are frequently truncated.
        var attempts = 0
        while (all.size < count && attempts < (count / 8 + 5)) {
            attempts++
            val remaining = count - all.size
            val batchSize = minOf(10, remaining)
            val prompt = buildCpetPrompt(topic, difficulty, batchSize) +
                "\nAvoid these previously generated questions: " +
                all.takeLast(25).joinToString(" | ") { it.stem.take(100) }
            var batch: List<Question> = emptyList()
            for ((index, model) in listOf(primaryModel, fallbackModel).withIndex()) {
                try {
                    val response = withTimeout(GENERATION_TIMEOUT_MS) { model.generateContent(prompt) }
                    val raw = response.text ?: error("AI returned an empty response")
                    batch = parseQuestionsJson(raw, topic)
                    if (batch.isEmpty()) error("AI returned no valid questions")
                    break
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    Log.w(TAG, "Gemini model attempt ${index + 1} failed", e)
                    lastException = e
                }
            }
            if (batch.isEmpty()) break
            for (question in batch) {
                val normalized = question.stem.trim().replace(Regex("\\s+"), " ")
                if (seen.add(normalized)) all.add(question)
                if (all.size == count) break
            }
        }
        if (all.isEmpty()) throw IllegalStateException(
            "AI could not generate questions. Check Firebase AI Logic, model access, App Check and internet connectivity.", lastException
        )
        if (all.size < count) throw IllegalStateException(
            "Only ${all.size} unique questions were generated out of $count. Try again or choose fewer questions."
        )
        return all
    }

    private fun buildCpetPrompt(
        topic: OdiaTopic,
        difficulty: TestDifficulty,
        count: Int
    ): String = """
        You are a senior professor of Odia Literature and Linguistics preparing official questions for the Odisha Common PG Entrance Test (CPET - MA Odia).

        Generate exactly $count original, high-accuracy multiple-choice questions.
        Topic: ${topic.titleEn} (${topic.titleOr})
        Syllabus Focus: ${topic.syllabusFocus}
        Difficulty Level: ${difficulty.labelEn} (${difficulty.labelOr})

        Strict Academic Rules:
        1. Write `stem`, all 4 `options`, `explanation`, and `topicTag` strictly in standard, grammatically accurate Odia Unicode script (ଓଡ଼ିଆ).
        2. Every question MUST have exactly 4 distinct options. `correctIndex` MUST be an integer in 0..3 matching the right option.
        3. Verify literary facts rigorously: authentic author names, kavyas, novels, dramas, chhandas (ଚଉତିଶା, ବଙ୍ଗଳାଶ୍ରୀ, ଦାଣ୍ଡିବୃତ୍ତ, କଳସା), alankaras, and linguistic rules. Never invent fictional works or misattribute texts.
        4. Make distractors plausible for postgraduate entrance aspirants (avoid obviously silly choices).
        5. Keep `explanation` (ବ୍ୟାଖ୍ୟା) concise (1-2 clear sentences in Odia) explaining why the answer is accurate.
    """.trimIndent()

    private fun parseQuestionsJson(jsonString: String, topic: OdiaTopic): List<Question> {
        val root = JSONObject(jsonString)
        val array = root.optJSONArray("questions") ?: return emptyList()
        val results = mutableListOf<Question>()

        for (i in 0 until array.length()) {
            val obj = array.optJSONObject(i) ?: continue
            val stem = obj.optString("stem").trim()
            val optionsJson = obj.optJSONArray("options") ?: continue
            val options = (0 until optionsJson.length())
                .map { optionsJson.optString(it).trim() }
                .filter { it.isNotEmpty() }
            val correctIndex = obj.optInt("correctIndex", -1)
            val explanation = obj.optString("explanation").trim()
            val topicTag = obj.optString("topicTag").trim().ifEmpty { topic.titleOr }

            if (stem.isNotEmpty() && options.size == 4 && options.distinct().size == 4 && correctIndex in 0..3) {
                results.add(
                    Question(
                        id = UUID.randomUUID().toString(),
                        topicKey = topic.name,
                        stem = stem,
                        options = options,
                        correctIndex = correctIndex,
                        explanation = explanation.ifEmpty { "ସଠିକ୍ ଉତ୍ତର: ${options[correctIndex]}" },
                        topicTag = topicTag
                    )
                )
            }
        }
        return results
    }
}
