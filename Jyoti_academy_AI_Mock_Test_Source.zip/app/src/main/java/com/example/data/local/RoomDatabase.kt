package com.example.data.local

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.domain.model.Question
import kotlinx.coroutines.flow.Flow
import org.json.JSONArray

@Entity(tableName = "cached_questions")
data class CachedQuestionEntity(
    @PrimaryKey val id: String,
    val topicKey: String,
    val difficulty: String,
    val stem: String,
    val optionsJson: String,
    val correctIndex: Int,
    val explanation: String,
    val topicTag: String,
    val createdAtEpochMs: Long,
    val timesAttempted: Int = 0
) {
    fun toDomain(): Question {
        val array = JSONArray(optionsJson)
        val options = (0 until array.length()).map { array.getString(it) }
        return Question(
            id = id,
            topicKey = topicKey,
            stem = stem,
            options = options,
            correctIndex = correctIndex,
            explanation = explanation,
            topicTag = topicTag
        )
    }

    companion object {
        fun fromDomain(question: Question, difficulty: String): CachedQuestionEntity {
            val array = JSONArray().apply {
                question.options.forEach { put(it) }
            }
            return CachedQuestionEntity(
                id = question.id,
                topicKey = question.topicKey,
                difficulty = difficulty,
                stem = question.stem,
                optionsJson = array.toString(),
                correctIndex = question.correctIndex,
                explanation = question.explanation,
                topicTag = question.topicTag,
                createdAtEpochMs = System.currentTimeMillis(),
                timesAttempted = 0
            )
        }
    }
}

data class TopicCacheCount(
    val topicKey: String,
    val count: Int
)

@Dao
interface CachedQuestionDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(questions: List<CachedQuestionEntity>)

    @Query(
        """
        SELECT * FROM cached_questions
        WHERE topicKey = :topicKey
        ORDER BY timesAttempted ASC, RANDOM()
        LIMIT :limit
        """
    )
    suspend fun getByTopic(topicKey: String, limit: Int): List<CachedQuestionEntity>

    @Query(
        """
        SELECT * FROM cached_questions
        ORDER BY timesAttempted ASC, RANDOM()
        LIMIT :limit
        """
    )
    suspend fun getAnyTopic(limit: Int): List<CachedQuestionEntity>

    @Query("SELECT topicKey, COUNT(*) as count FROM cached_questions GROUP BY topicKey")
    fun observeTopicCounts(): Flow<List<TopicCacheCount>>

    @Query("SELECT COUNT(*) FROM cached_questions")
    fun observeTotalCount(): Flow<Int>

    @Query("UPDATE cached_questions SET timesAttempted = timesAttempted + 1 WHERE id IN (:ids)")
    suspend fun incrementAttempted(ids: List<String>)

    @Query("DELETE FROM cached_questions")
    suspend fun clearAll()
}

@Database(entities = [CachedQuestionEntity::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun cachedQuestionDao(): CachedQuestionDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "odia_pg_mock_cache.db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}
