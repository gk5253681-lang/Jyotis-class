# Jyoti academy — original native Android project

This is the user's original Jetpack Compose project, **not** the unrelated AppCreator24 quiz. Original screens, navigation, Room cache, bookmarks, Firebase login and results are preserved.

## Improvements in this edition
- Gemini model names corrected to `gemini-2.5-flash` and `gemini-2.5-flash-lite`.
- Gemini Developer API backend explicitly selected via Firebase AI Logic.
- AI questions are generated in batches of up to 10, allowing tests of up to 100 questions and reducing JSON truncation.
- Duplicate question stems and repeated options are rejected. If the AI cannot return the requested count, a clear error is displayed rather than silently pretending a complete exam was generated.
- Launcher name is Jyoti academy. Offline generated-question caching and all existing features are preserved.

## Requirements and caveats
- Configure the included Firebase project for Firebase AI Logic with Gemini Developer API, enable required authentication, Firestore and App Check. Firebase service config is not itself an AI API key. Free-tier availability and limits depend on Google's current terms.
- This is **not** an OpenAI/Claude integration: only Gemini is implemented in the original code. Other providers require a secure backend and credentials.
- Generated content may be inaccurate; verify exam-critical facts.
- A successful APK compile has **not** been performed here. This archive contains a GitHub Actions build workflow (`.github/workflows/build-apk.yml`) that can compile and upload a debug APK once pushed to a GitHub repository. The project does not contain a full Gradle wrapper; the workflow installs Gradle.
- The original application ID `com.aistudio.odiapgmock.kxpqzm` is preserved for Firebase compatibility.
